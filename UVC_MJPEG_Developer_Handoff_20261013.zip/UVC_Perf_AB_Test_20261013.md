﻿# 2026-10-13 UVC 4K MJPEG 对照记录

条件：用户确认 4K MJPEG 实时更新、最高 CPU/interconnect。CPU 频率实测 1804800 / 2419200 / 2841600 kHz；interconnect 未独立验证。

- A1 原始亲和性、irqbalance 运行：60 秒 4 次闪烁，分散，无卡顿。
- B1 JPEG IRQ325 固定 CPU3、irqbalance 暂停：60 秒 2 次闪烁，分散，无卡顿。
- A2 恢复 JPEG 原始亲和性、irqbalance 运行：60 秒 5 次闪烁，分散，无卡顿。

限制：人工观察窗口没有逐次时间标记，消息到达与采样窗口有偏差。B1 同时改变 JPEG 亲和性及 irqbalance 状态，不能归因于单一因素。最近窗口 JPEG/DWC3 IRQ 计数不增长，尽管用户确认实时画面，需要确认中断与实际视频路径的关系。

性能：A2 回复前约60秒 CPU5 100%忙碌；UMD TID5484 运行约60.315秒，调度等待增加约0.128毫秒；CPU0/1 平均19.4%/11.5%；CPU2–4几乎空闲；频率未下降。不能据此判断 JPEG reset，也不能认为 CPU5 满载是根因。

下一轮 C：仅暂停 irqbalance，不主动修改中断亲和性，测试暂停本身的影响。

设备 boot_id: fd12e298-b87a-421d-b7a5-105abcdc6a89
数据文件：uvc_perf_boot2.txt；设备采样及标记目录 /data/local/tmp/uvc_perf_boot2。
恢复：adb shell sh /data/local/tmp/uvc_perf_boot2/restore_irq.sh
- C1 仅暂停 irqbalance，JPEG CPU1 / USB CPU0：60 秒闪烁 3 次，分散，无卡顿。
- D1 已开始：保持 irqbalance 暂停、USB CPU0，只将 JPEG 从 CPU1 改为 CPU3。

- D1 JPEG CPU3、irqbalance 暂停、USB CPU0：60 秒闪烁 1 次，无卡顿。
- C2 反向对照已开始：仅将 JPEG 恢复 CPU1，irqbalance 继续暂停、USB CPU0。观察窗口缺少精确开始/结束标记，结果需重复确认。

- C2 JPEG CPU1、irqbalance 暂停、USB CPU0：60 秒闪烁 9 次，含连续闪烁，无卡顿。
- D2 已开始：只将 JPEG 再次移到 CPU3，其余不变。

- D2 JPEG CPU3、irqbalance 暂停、USB CPU0：60 秒闪烁 6 次，分散，无卡顿。
- CPU1→CPU3→CPU1→CPU3 为3→1→9→6次/60秒。改善未稳定复现，窗口不精确且负载状态变化，不能确认绑核有效或JPEG reset根因。已恢复JPEG原始亲和性及irqbalance运行；性能采样继续。
